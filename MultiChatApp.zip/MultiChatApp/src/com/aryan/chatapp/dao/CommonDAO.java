package com.aryan.chatapp.dao;

import java.sql.Connection;

//Throw early and catch later -> we start throwing the exceptions from deep classes and the main calling method will catch 
import java.sql.DriverManager;
import java.sql.SQLException;
import static com.aryan.chatapp.utils.ConfigReader.getValue;
public interface CommonDAO {
	//static methods are allowed
	public static Connection createConnection() throws ClassNotFoundException, SQLException {
		//Step 1: Load a Driver 
		Class.forName(getValue("DRIVER")); //it is RuntimeException as thise will 
		//work in real time and we could have written the wrong name/path of the driver
		
		//Step 2: Making a Connection
		final String CONNECTION_STRING = getValue("CONNECTION");
		final String USER_ID = getValue("USERID");
		final String PASSWORD = getValue("PASSWORD");
		Connection con = DriverManager.getConnection(CONNECTION_STRING, USER_ID, PASSWORD);
		if(con != null) {
			System.out.println("Connection Created...");
		}
		return con;
	}
	

}
