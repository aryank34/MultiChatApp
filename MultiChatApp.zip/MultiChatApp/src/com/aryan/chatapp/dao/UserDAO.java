package com.aryan.chatapp.dao;

import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.aryan.chatapp.dto.UserDTO;
import com.aryan.chatapp.utils.Encryption;

//USER CRUD Operations
public class UserDAO {
	
	public boolean isLogin(UserDTO userData) throws SQLException, ClassNotFoundException, Exception{
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		final String SQL = "Select userid from users where userid=? and password=?";
		try {
			con = CommonDAO.createConnection();
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, userData.getUserid());
			String encryptedPwd = Encryption.passwordEncrypt(new String(userData.getPassword()));
			pstmt.setString(2, encryptedPwd);
			rs = pstmt.executeQuery();
			
//			if(rs.next()) { //means that row is there for the given userid & password
//				return true;
//			}else {
//				return false;
//			}
			return rs.next();
		}
		finally {
			if(rs!=null) {
				rs.close();
			}
			if(pstmt!=null) {
				pstmt.close();
			}
			if(con!=null) {
				con.close();
			}
		}
	}
	
	
	public int add(UserDTO userData) throws ClassNotFoundException, SQLException, Exception{ //it acts like a handbag. put everything inside it and send it once together
		//System.out.println("Record:"+userData.getUserid()+" "+userData.getPassword());
		
		//now put the records into the database
		
		//create connection
		Connection connection = null;
		
		//to write queries
		Statement stmt = null;
		try {
			//now we dont want to make objects of CommonDao, so we made it interface
			connection = CommonDAO.createConnection(); //STEP 1: connection created
			
			stmt = connection.createStatement(); //STEP 2: write a query
			//new String() creates a new string, otherwise it would have given hashcode.
			int record = stmt.executeUpdate("insert into users (userid, password) values (\"" + userData.getUserid()+"\",\""+Encryption.passwordEncrypt(new String(userData.getPassword()))+"\");"); //Insert, delete, update
			return record; //1 -> added, 0->error
		}
		finally { //Always executes except System.exit(0); and always used with try{}
			if(stmt != null) {
				stmt.close();
			}
			if(connection != null) {
				connection.close();
			}
		}
	}
	
}
