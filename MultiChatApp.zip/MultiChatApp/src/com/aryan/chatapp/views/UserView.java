package com.aryan.chatapp.views;

import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class UserView extends JFrame{
	int counter;
	public UserView() {
		//login screen features
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(400,400);
		//setLocation(500,150);
		setLocationRelativeTo(null); //screen always in the centre
		setResizable(false); //can't resize now
		setTitle("LOGIN");
		
		//login screen components
		JLabel welcome = new JLabel("Login");
		welcome.setFont(new Font("times",Font.BOLD,40));
		Container container = this.getContentPane(); //this is a virtual box which we have our content
		
		//default layout of container is BOX Layout
		//we will set the layout to null -> no layout
		container.setLayout(null);
		
		welcome.setBounds(130, 50, 200, 60);
		container.add(welcome); //adding JLabel to container
		
		//add a button
		JButton button = new JButton("Count"); //source
		button.addActionListener(new ActionListener() { //Action Listener is an interface
			//hence we created an anonymous class to implement all the methods of interface
			
			@Override
			public void actionPerformed(ActionEvent e) {
				counter++;
				welcome.setText("Count: "+counter);
				
			}
		});
		button.setBounds(135,300,100,25);
		container.add(button);
		
		setVisible(true);
	}

	public static void main(String[] args) {
		UserView userView = new UserView();
		
	}

}
